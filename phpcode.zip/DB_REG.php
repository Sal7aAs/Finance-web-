<?php
session_start();
$username = filter_input(INPUT_POST, 'username');
$email = filter_input(INPUT_POST, 'email');
$password = filter_input(INPUT_POST, 'password');

if (!empty($username)) {
    if (!empty($password)) {
        $host = "localhost";
        $dbusername = "Finance";
        $dbpassword = "Ahmad123";
        $dbname = "finance";

        // Create connection
        $conn = new mysqli($host, $dbusername, $dbpassword, $dbname);
        if (mysqli_connect_error()) {
            die('Connect Error (' . mysqli_connect_errno() . ')' . mysqli_connect_error());
            
        } else {
            // Prepare SQL statement
            $sql = "INSERT INTO users (username, email, password) VALUES (?,?,?)";
            $stmt = $conn->prepare($sql);
            if ($stmt) {
                // Bind parameters and execute the statement
                $stmt->bind_param("sss", $username, $email, $password);
                if ($stmt->execute()) {
                     // Registration successful, redirect to login page
                     header("Location: login.php");
                     exit();
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                // Close statement
                $stmt->close();
            } else {
                echo "Error preparing statement: " . $conn->error;
            }
            // Close connection
            $conn->close();
        }
    } else {
        echo "Password should not be empty";
        die();
    }
} else {
    echo "Username should not be empty";
    die();
}
?>
