<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Finance Manager</title>
    <link rel="stylesheet" href="styles.css">
    <script src="fun.js" defer></script>

</head>
<body class="m1">
<header>
    <!-- Logo section -->
    <div class="logo">
        <img src="images/im16.jpg" alt="Logo/im16" width="100">
    </div>
    <!-- Texts in header -->
    <h1>Finance</h1>
    <p>Take control of your investments and achieve your goals</p>
    <!-- Elements top right -->
    <nav class="main">
        <ul id="menuList">
            <li><a href="tool.php">Financial Tool</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="help.php">Support</a></li>
        </ul>
        <img src="images/menu.png" alt="menu" class="menu-icon" onclick="press()">
    </nav>
</header>


    <main>
        <!--Flipping images Section where images are supposed to rotate/flip and show text on the background -->
        <section id="section1" class="sec1">
            <div class="section-content">
                <h2>Let's Craft Your Tomorrow</h2>
                <div class="image-container">
                    <div class="image-wrapper">
                        <img src="images/im30.jpg" alt="Stocks/im30" class="flip-image">
                        <div class="image-text">Whether you're a seasoned investor seeking to fine-tune your portfolio or a novice eager to embark on the journey of wealth creation, We offer personalized guidance tailored to your financial goals. Let's navigate the complexities of the stock market together and pave the way to sustainable growth and prosperity</div>
                    </div>
                    <div class="image-wrapper">
                        <img src="images/im31.jpeg" alt="Investment" class="flip-image">
                        <div class="image-text">Enhance your financial path with our extensive proficiency in both real estate and gold investments. Supported by a wealth of knowledge and hands-on experience, Wedeliver customized strategies to optimize your returns and minimize risks within these thriving sectors</div>
                    </div>
                    <div class="image-wrapper">
                        <img src="images/im5.jpg" alt="Digital Coins" class="flip-image">
                        <div class="image-text">Intrigued by Bitcoin's potential as a store of value or exploring the diverse world of altcoins? We provide insightful guidance to navigate the complexities and seize profitable prospects. Let's harness the transformative power of digital currencies together to pave the way for financial growth and security</div>
                    </div>
                </div>
            </div>
        </section>
        <!--Brief summary: a small description of our webiste's -->
        <section class="secc">
            <h2>Why Us ?</h2>
            <p><strong>We are dedicated to empowering individuals to take control of their finances and achieve their goals. With our innovative tools and expert guidance, we help our clients navigate the complexities of personal finance, providing tailored solutions to meet their unique needs.</strong></p>
            <p><strong>Whether you're saving for a dream vacation, planning for retirement, or looking to build wealth for the future, our team of financial experts is here to support you every step of the way. From budgeting and investing to debt management and financial planning, we offer comprehensive services to help you secure a brighter financial future.</strong></p>
            <p><strong>Join us today and discover how Personal Finance Manager can help you turn your financial dreams into reality!</strong></p>
        </section>
        <!-- Randomly generate icons in one section :icons will appear randomly all over the section in diff places -->
        <section class="icon-section secc">
        <img src="images/im50.png" class="icon" >
            <img src="images/im51.png" class="icon" >
            <img src="images/im52.png" class="icon" >
            <img src="images/im54.png" class="icon" >
            <img src="images/im55.png" class="icon" >
            <img src="images/im57.png" class="icon" >
            <img src="images/im58.png" class="icon" >
            <img src="images/im59.png" class="icon" >
            <img src="images/im60.png" class="icon" >
            <img src="images/im66.png" class="icon" >
            
        </section>
        <!-- Socials Insta, Facebook, Help, and profile -->
        <section class="secc">
            <p><span class="animated-letter">W</span>e are a pioneering finance company renowned for our expertise in gold, stocks, and cryptocurrencies. With a rich legacy of success spanning generations, we have consistently delivered unparalleled investment solutions tailored to our clients' needs. Whether it's navigating the fluctuating markets of gold, maximizing returns in the dynamic realm of stocks, or harnessing the potential of cryptocurrencies like Bitcoin, our seasoned team of professionals brings decades of experience to every financial endeavor. Trust in our legacy, expertise, and commitment to excellence as we continue to lead the way in the ever-evolving landscape of finance.</p>
        </section>
        <section class="secc">
            <div class="social-icons">
                <img src="images/imm11.png" class="icon1">
                <img src="images/imm12.png" class="icon1">
                <img src="images/imm15.png" class="icon1">
                <img src="images/imm14.png" class="icon1">
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Personal Finance Manager</p>
    </footer>

    <script>
    var menuList = document.getElementById("menuList");
menuList.style.maxHeight = "0PX";
function press(){
    if(menuList.style.maxHeight =="0px"){
        menuList.style.maxHeight = "195px";
    }
    else{
        menuList.style.maxHeight = "0PX";

    }

}
</script>

</body>
</html>
