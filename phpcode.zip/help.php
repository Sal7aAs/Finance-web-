<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help & Support</title>
    <link rel="stylesheet" href="styles.css">
    <script src="fun.js" defer></script>
</head>
<body class="m1">
    <header>
        <!--Logo-->
        <div class="logo">
            <img src="images/im16.jpg" alt="Logo" width="100">
        </div>
         <!--Texts in header-->
        <h1>Help & Support</h1>
        <p>How Can We Assist You Today?</p>
        <!--Elements top right-->
        <nav class="main">
            <ul id="menuList">
                <li><a href="index.php">Home</a></li>
                
            </ul>
            <img src="images/menu.png" alt="menu" class="menu-icon" onclick="press()">
        </nav>
    </header>

    <main>
        <!--This section will contain 3 icons , phone, mail and chat, icons will keep on wiggling until being hovered on.
        The icon chosen will stop while the rest continue-->
        <div class="contact-options">
           
            <div class="option">
                <img src="images/immm1.png" alt="Phone Icon">
                <h2>Call Us</h2>
                <p>+1 (800) 123-4567</p>
            </div>
            <div class="option">
                <img src="images/immm2.png" alt="Email Icon">
                <h2>Email Us</h2>
                <p>support@finance.com</p>
            </div>
            <div class="option">
                <img src="images/immm3.png" alt="Chat Icon">
                <h2>Live Chat</h2>
                <p>Connect with an advisor</p>
            </div>
        </div>
        <!--Feedback form where we can take clients feedback on spot-->
        <section class="feedback-section">
            <h2 class="faq-item">Feedback Form</h2>
            <form id="feedback-form" class="cool-form" action="submit_feedback.php" method="post"> <!-- Assuming you have a PHP file named 'submit_feedback.php' to handle form submission -->
                <div class="form-group">
                    <label for="name">Your Name:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Your Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="feedback">Your Feedback:</label>
                    <textarea id="feedback" name="feedback" rows="5" required></textarea>
                </div>
                <button type="submit">Submit Feedback</button>
            </form>
        </section>
        
        <!--Cool section where it displays some faqs,those faqs will be shown as a question until being clicked on then they will display the answers -->
        <section class="faq-section">
            <h2 class="faq-item">Frequently Asked Questions</h2>
            <div class="faq-item">
                <h3 class="faq-question">Question 1: What are the supported payment methods?</h3>
                <div class="faq-answer">
                    <p>Answer: We currently support credit card payments, PayPal, and bank transfers.</p>
                </div>
            </div>
            <div class="faq-item">
                <h3 class="faq-question">Question 2: How do I reset my password?</h3>
                <div class="faq-answer">
                    <p>Answer: To reset your password, go to the login page and click on the "Forgot Password" link. Follow the instructions to reset your password.</p>
                </div>
            </div>
            
        </section>
        <!--Socials Insta, Facebook, Help, and profile -->
        <section class="secc">
            <div class="social-icons">
                <img src="images/imm11.png" class="icon1">
                <img src="images/imm12.png" class="icon1">
                <img src="images/imm15.png" class="icon1">
                <img src="images/imm14.png" class="icon1">
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Personal Finance Manager</p>
    </footer>

    <script>
    var menuList = document.getElementById("menuList");
menuList.style.maxHeight = "0PX";
function press(){
    if(menuList.style.maxHeight =="0px"){
        menuList.style.maxHeight = "195px";
    }
    else{
        menuList.style.maxHeight = "0PX";

    }

}
</script>

</body>
</html>
