<?php

require_once 'db_log.php'; // Include the file containing login functionality

// Redirect user to profile page if already logged in
//

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if username and password are set
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        

        // Attempt login
        if (login($username, $password, $pdo)) {
            
           
            // Redirect to profile page upon successful login
            header("Location: profile.php");
            exit();
        } else {
            // Display error message for invalid credentials
            $error = "Invalid username or password.";
            $echo = $error;
        }
    }
    exit();
    
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="styles.css">
    <script src="fun.js" defer></script>
</head>
<body class="m1">
    <header>
        <!-- logo-->
        <div class="logo">
            <img src="images/im16.jpg" alt="Logo" width="100">
        </div>
         <!--Texts in header-->
        <h1>Login</h1>
        <p>One Step Closer To success</p>
        <!--Elements top right-->
        <nav class="main">
            <ul id="menuList">
                <li><a href="index.php">Home</a></li>
                <li><a href="help.php">Help</a></li>
            </ul>
            <img src="images/menu.png" alt="menu" class="menu-icon" onclick="press()">
        </nav>
    </header>
    <main>
        <!--login form: creating a form to login existing user -->
        <div class="login-container icon-section">
            <h2>Login</h2>
            <?php if (isset($error)) echo "<p>$error</p>"; ?>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="input-group">
                    <input type="text" id="username" name="username" placeholder="Username" required>
                </div>
                <div class="input-group">
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
                <button type="submit">Login</button>
                <p id="register"> Don't have an account? <a href="register.php">Register</a></p>
            </form>
            <img src="images/imm16.png" class="icon" >
        </div>
        <!--Socials Insta, Facebook, Help, and profile -->
        <section class="secc">
            <div class="social-icons">
                <img src="images/imm11.png" class="icon1">
                <img src="images/imm12.png" class="icon1">
                <img src="images/imm15.png" class="icon1">
                <img src="images/imm14.png" class="icon1">
            </div>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Personal Finance Manager</p>
    </footer>

    <script>
    var menuList = document.getElementById("menuList");
menuList.style.maxHeight = "0PX";
function press(){
    if(menuList.style.maxHeight =="0px"){
        menuList.style.maxHeight = "195px";
    }
    else{
        menuList.style.maxHeight = "0PX";

    }

}
</script>

</body>
</html>
