
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>
    <link rel="stylesheet" href="styles.css">
    <script src="fun.js" defer></script>

    
</head>
<body class="m1">

    <header>
        <!--Logo sect -->
        <div class="logo">
            <img src="images/im16.jpg" alt="Logo" width="100">
        </div>
        <!--Texts in header-->
        <h1>Register</h1>
        <p>Aren't You A Member Yet?</p>
        <!--Elements top right-->
        <nav class="main">
            <ul id="menuList">
                <li><a href="index.php">Home</a></li>
            </ul>
            <img src="images/menu.png" alt="menu" class="menu-icon" onclick="press()">
        </nav>
    </header>
<main>
    <div class="login-container">
        <h2><span class="animated-word">Register</span></h2><!--Special Register highlight-->
        <form id="insertForm" action="DB_REG.php" method="post" onsubmit="return validateForm()">

            <div class="input-group">
                <input type="text" id="username" name="username" required>
                <label for="username">Username</label>
            </div>
            <div class="input-group">
                <input type="email" id="email" name="email" required>
                <label for="email">Email</label>
            </div>
            <div class="input-group">
                <input type="password" id="password" name="password" required>
                <label for="password">Password</label>
            </div>
            <div class="input-group">
                <input type="password" id="confirm-password" name="confirm-password" required>
                <label for="confirm-password">Confirm Password</label>
            </div>
            <button type="submit">Register</button>
            <!-- Add a div for the custom popup -->
            <div id="popup" class="popup">
    <div class="popup-content">
        <span class="close" onclick="closePopup()">&times;</span>
        <p id="popup-message"></p>
    </div>
</div>
        </form>
        <p>Already have an account? <a href="login.php">Login</a></p>
    </div>

    </main>


    <footer>
        <p>&copy; 2024 Personal Finance Manager</p>
    </footer>

    <script>
    var menuList = document.getElementById("menuList");
menuList.style.maxHeight = "0PX";
function press(){
    if(menuList.style.maxHeight =="0px"){
        menuList.style.maxHeight = "195px";
    }
    else{
        menuList.style.maxHeight = "0PX";

    }

}
</script>
</body>
</html>
