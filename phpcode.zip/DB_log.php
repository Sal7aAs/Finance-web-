<?php
require 'Db/database.php';

function login($username, $password, $pdo) {
    // Check credentials against database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username AND password = :password");
    $stmt->execute(['username' => $username, 'password' => $password]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
  
    

    if ($user) {
        $_SESSION['username'] = $username; // Store username in session
        $_SESSION['email'] = $user['email']; // Store email in session

        // Debugging: Print email for verification
        echo "Email from database: " . $user['email'];

        return true; // Login successful
    } else {
        return false; // Invalid username or password
    }

   


}


?>
