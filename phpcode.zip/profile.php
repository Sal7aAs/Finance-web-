<?php
include'db_log.php';


// Redirect user to login page if not logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Get the username from the session
$username = $_SESSION['username'];
// Get the email from the session

$user['email'] = $_SESSION['email'];




?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="styles.css">
    <script src="fun.js" defer></script>

  
    
</head>
<body class="m1">

<header>
    <div class="logo">
        <img src="images/im16.jpg" alt="Logo" width="100">
    </div>
    <h1>Welcome, <?php echo $username; ?></h1>
    <p>Money Is Calling</p>
    <p>Email: <?php echo $_SESSION['email']; ?></p>
    <nav class="main">
        <ul id="menuList">
            <li><a href="index.php">Home</a></li>
            <li><a href="help.php">Support</a></li>
            
            <li><a href="#" onclick="document.getElementById('logoutForm').submit();">Logout</a></li>
        </ul>
        <img src="images/menu.png" alt="menu" class="menu-icon" onclick="press()">
    </nav>
</header>

<main>
    <div class="container">
        <div class="profile-header">
            <h2>Profile</h2>
        </div>

        <div class="user-info">
            <h3>User Information</h3>
            <div class="info-item">
                <label>Name: <span><?php echo $username; ?></span></label>
                
            </div>

            <div class="info-item">
                <label>Email: <span><?php echo $user['email'] ; ?></span></label>
                
            </div>
            <!-- Add more user information items as needed -->
        </div>

        <div class="account-settings">
            <h3>Account Settings</h3>
            <form method="post">

            <div class="form-group">
                    <label for="current-password">Current Password:</label>
                    <input type="password" id="current-password" name="current-password">
                </div>

                <div class="form-group">

                    <label for="new-password">New Password:</label>
                    <input type="password" id="new-password" name="new-password">
                </div>
                <div class="form-group">
                    <label for="confirm-password">Confirm Password:</label>
                    <input type="password" id="confirm-password" name="confirm-password">
                </div>
                <button type="submit" name="update-password">Update Password</button>
            </form>
        </div>
        <div class="goal-tracker">
            <h3>Goal Tracker</h3>
            <div class="goal-item">
                <h4>Save for Vacation</h4>
                <p>Target Amount: $2000</p>
                <p>Current Progress: $1500</p>
            </div>
            <!-- Add more goal items as needed -->
            <button onclick="showPopup()">Add Goal</button> <!-- Button to show popup -->
        </div>
    </div>

   
</main>

<footer>
    <p>&copy; 2024 Personal Finance Manager</p>
</footer>

<!-- Hidden form for logout -->
<form id="logoutForm" method="post" style="display: none;">
    <input type="hidden" name="logout">
</form>

<script>
    var menuList = document.getElementById("menuList");
menuList.style.maxHeight = "0PX";
function press(){
    if(menuList.style.maxHeight =="0px"){
        menuList.style.maxHeight = "195px";
    }
    else{
        menuList.style.maxHeight = "0PX";

    }

}
</script>

</body>
</html>
