
// script.js
// JavaScript for adding a pulsating effect with gradient color fading to the logo

const logo = document.querySelector('.logo');

let scaleFactor = 1.2; // Initial scale factor
let scaleDirection = 1;
let hue = 0;

function pulsateLogo() {
    scaleFactor += 0.005 * scaleDirection; // Increment scale factor slowly
    if (scaleFactor >= 1.3 || scaleFactor <= 1.1) {
        scaleDirection *= -1; // Reverse scale direction at upper/lower bounds
    }
    logo.style.transform = `scale(${scaleFactor})`; // Apply scaling
    
    // Change hue for color (gradual change)
    hue = (hue + 1) % 360;
    const color1 = `hsl(${hue}, 100%, 50%)`; // First color
    const color2 = `hsl(${(hue + 180) % 360}, 100%, 50%)`; // Second color (180 degrees apart)
    logo.style.filter = `url(#gradientFade)`; // Apply gradient fade filter
    
    requestAnimationFrame(pulsateLogo); // Loop animation
}

pulsateLogo(); // Start the pulsating animation

document.addEventListener('DOMContentLoaded', function() {
    const icons = document.querySelectorAll('.icon');

    function animateIcons() {
        icons.forEach(icon => {
            // Randomly generate new position for each icon
            const x = Math.random() * (window.innerWidth - icon.clientWidth);
            const y = Math.random() * (window.innerHeight - icon.clientHeight);

            // Set new position
            icon.style.left = `${x}px`;
            icon.style.top = `${y}px`;

            // Randomly show/hide icons
            if (Math.random() > 0.6) {
                icon.style.display = 'block';
            } else {
                icon.style.display = 'none';
            }
        });

        // Repeat animation every 3 seconds
        setTimeout(animateIcons, 1000);
    }

    animateIcons(); // Start the animation
});

// help and support page 
document.addEventListener('DOMContentLoaded', function() {
    const faqQuestions = document.querySelectorAll('.faq-question');

    faqQuestions.forEach(function(question) {
        question.addEventListener('click', function() {
            const answer = question.nextElementSibling;
            answer.classList.toggle('active'); // Toggle active class for answer
        });
    });
});




document.getElementById('investment-form').addEventListener('submit', function(event) {
    event.preventDefault();
    calculateInvestment();
});

function calculateInvestment() {
    const initialInvestment = parseFloat(document.getElementById('initial-investment').value);
    const interestRate = parseFloat(document.getElementById('interest-rate').value) / 100;
    const investmentDuration = parseInt(document.getElementById('investment-duration').value);

    const futureValue = initialInvestment * Math.pow(1 + interestRate, investmentDuration);
    displayResult(futureValue);
}

function displayResult(futureValue) {
    const resultElement = document.getElementById('result');
    const futureValueElement = document.getElementById('future-value');

    futureValueElement.textContent = '$' + futureValue.toFixed(2);
    resultElement.classList.remove('hidden');
}

//game
document.addEventListener('DOMContentLoaded', function() {
    const balanceDisplay = document.getElementById('balance');
    const feedbackText = document.getElementById('feedback-text');
    let balance = 100; // Initial balance

    // Function to update balance display
    function updateBalance() {
        balanceDisplay.textContent = balance.toFixed(2);
    }

    // Event listener for earning money button
    document.getElementById('earn-btn').addEventListener('click', function() {
        balance += 10; // Earn $10
        feedbackText.textContent = 'You earned $10.';
        updateBalance();
    });

    // Event listener for spending money button
    document.getElementById('spend-btn').addEventListener('click', function() {
        if (balance >= 10) {
            balance -= 10; // Spend $10 if balance is sufficient
            feedbackText.textContent = 'You spent $10.';
            updateBalance();
        } else {
            feedbackText.textContent = 'You do not have enough money to spend!';
        }
    });

    // Event listener for investing money button
    document.getElementById('invest-btn').addEventListener('click', function() {
        if (balance >= 50) {
            balance -= 50; // Invest $50 if balance is sufficient
            feedbackText.textContent = 'You invested $50.';
            updateBalance();
        } else {
            feedbackText.textContent = 'You do not have enough money to invest!';
        }
    });

    // Event listener for selling investment button
    document.getElementById('sell-btn').addEventListener('click', function() {
        if (balance >= 50) {
            balance += 50; // Sell investment for $50
            feedbackText.textContent = 'You sold your investment for $50.';
            updateBalance();
        } else {
            feedbackText.textContent = 'You do not have any investment to sell!';
        }
    });
});


document.addEventListener('DOMContentLoaded', function() {
    // Function to generate random data for each dataset
    function generateRandomData() {
        const data = [];
        for (let i = 0; i < 7; i++) {
            data.push(Math.floor(Math.random() * 1000)); // Generate random prices
        }
        return data;
    }

    // Function to create the stock chart with multiple datasets
    function createStockChart() {
        const ctx = document.getElementById('stock-chart').getContext('2d');
        const myChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [
                    {
                        label: 'Bitcoin',
                        data: generateRandomData(),
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 2,
                        fill: false
                    },
                    {
                        label: 'Gold',
                        data: generateRandomData(),
                        borderColor: 'rgba(255, 206, 86, 1)',
                        borderWidth: 2,
                        fill: false
                    },
                    {
                        label: 'Real Estate',
                        data: generateRandomData(),
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 2,
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    }

    createStockChart(); // Create stock chart when the page loads
});

function validateForm() {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirm-password").value;

    if (password !== confirmPassword) {
        showPopup("Passwords do not match!");
        return false; // Prevent form submission
    }
    return true; // Allow form submission if passwords match
}

// Modified showPopup() function to display the custom popup
function showPopup(message) {
    var popup = document.getElementById('popup');
    var popupMessage = document.getElementById('popup-message');

    popupMessage.textContent = message;
    popup.style.display = 'block';
}

// Modified closePopup() function to close the custom popup
function closePopup() {
    var popup = document.getElementById('popup');
    popup.style.display = 'none';
}




