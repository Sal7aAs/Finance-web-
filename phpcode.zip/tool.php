<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Tool Page</title>
    <link rel="stylesheet" href="styles.css">
    <script src="fun.js" defer></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="m1">
    <header>
        <!--lOGO-->
        <div class="logo">
            <img src="images/im16.jpg" alt="Logo" width="100">
        </div>
        <!--Texts in header-->
        <h1>Financial Tool</h1>
        <p>Where Magic Begins</p>
        <!--Elements top right-->
        <nav class="main">
            <ul id="menuList">
                <li><a href="index.php">Home</a></li>
                <li><a href="help.php">Support</a></li>
            </ul>
            <img src="images/menu.png" alt="menu" class="menu-icon" onclick="press()">
        </nav>
    </header>

    <main>
        <!---Calculator tool Section: A calculator that will be built to make investment calculations, it will take an amount
        interest rate and duration then will display the total investment that will be earned -->
        <section class="contact-options">
            <div class="gold-rain left"></div> <!--An extra section to make it seem like money rain is pouring on the side-->
            <div class="calculator">
                <h2>Investment Calculator</h2>
                <form id="investment-form">
                    <div class="form-group">
                        <label for="initial-investment">Initial Investment ($)</label>
                        <input type="number" id="initial-investment" required>
                    </div>
                    <div class="form-group">
                        <label for="interest-rate">Annual Interest Rate (%)</label>
                        <input type="number" id="interest-rate" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="investment-duration">Investment Duration (years)</label>
                        <input type="number" id="investment-duration" required>
                    </div>
                    <button type="submit">Calculate</button>
                </form>
                <div id="result" class="hidden">
                    <h3>Future Value of Investment:</h3>
                    <p id="future-value"></p>
                </div>
            </div>
            <div class="gold-rain right"></div><!--An extra section to make it seem like money rain is pouring on the side-->
        </section>

        <!---Chart Section: Full JavaScript library to create a chart that changes every time we refresh 
        it will show rates of bitcoin, real estate, and gold -->
        <div class="stock-chart contact-options">
            <canvas id="stock-chart"></canvas>
        </div>

        <!---Game Section: A game that can help the user understand money, investing, spending, earning, and selling 
        it will give the user $100 to start with, afterwards his decision will make the difference -->
        <section class="contact-options">
            <div class="game-container">
                <h1><strong> Management Game</h1>
                <div class="money-display">
                    <p>Your Current Balance: <span class="animated-letter">$</span><span id="balance" >100</span></p>
                </div>
                <div class="buttons">
                    <button id="earn-btn">Earn Money</button>
                    <button id="spend-btn">Spend Money</button>
                    <button id="invest-btn">Invest Money</button>
                    <button id="sell-btn">Sell Investment</button>
                </div>
                <div class="feedba">
                    <p id="feedback-text"><Strong>Welcome to the Money Management Game! Click the buttons to make decisions.</p>
                </div>
            </div>
        </section>

        <!--Socials Insta, Facebook, Help, and profile -->
        <section class="secc">
            <div class="social-icons">
                <img src="images/imm11.png" class="icon1" >
                <img src="images/imm12.png" class="icon1" >
                <img src="images/imm15.png" class="icon1" >
                <img src="images/imm14.png" class="icon1" >
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Personal Finance Manager</p>
    </footer>

    <script>
    var menuList = document.getElementById("menuList");
menuList.style.maxHeight = "0PX";
function press(){
    if(menuList.style.maxHeight =="0px"){
        menuList.style.maxHeight = "195px";
    }
    else{
        menuList.style.maxHeight = "0PX";

    }

}
</script>
</body>
</html>
